package com.example.medicine_classifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
