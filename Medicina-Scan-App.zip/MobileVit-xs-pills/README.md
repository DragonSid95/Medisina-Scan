# medicine_classifier

A new Flutter project.
