import 'dart:io';
import 'dart:convert'; 
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';
import 'classifier.dart';

// --- GLOBAL DATABASE ---
final List<Map<String, dynamic>> medicineDatabase = const [
  {
    "modelLabel": "Alaxan",
    "name": "Alaxan fr capsule",
    "use": "Relieves body aches, muscle pains, and inflammation.",
    "image": "assets/medicines/alaxan.jpg",
    "url":
        "https://www.mims.com/philippines/image/info/alaxan-fr-cap/200-mg-325-mg?id=2c4e6be3-9184-440f-ae15-a51d010d8688",
    "color": ["Cream", "Orange"],
    "shape": "Capsule",
    "form": "Capsule",
    "markings": "ALAXAN"
  },
  {
    "modelLabel": "Bactidol",
    "name": "Bactidol extra soothing loz",
    "use": "Soothes sore throats and treats minor mouth infections.",
    "image": "assets/medicines/bactidol.jpg",
    "url":
        "https://www.mims.com/philippines/image/info/bactidol-extra-soothing-loz?id=b8b80b9b-ad3f-478a-9d0a-b29500d86b27",
    "color": ["Orange"],
    "shape": "Round",
    "form": "Lozenge",
  },
  {
    "modelLabel": "Bioflu",
    "name": "Bioflu tablet",
    "use": "Relieves combined flu symptoms, fever, and heavy cough.",
    "image": "assets/medicines/bioflu.jpg",
    "url":
        "https://www.mims.com/philippines/image/info/bioflu-tab/10-mg-2-mg-500-mg?id=b43afd47-1db4-4d68-bfca-a51d010eaeba",
    "color": ["Blue"],
    "shape": "Oblong",
    "form": "Tablet",
    "markings": "BIOFLU"
  },
  {
    "modelLabel": "Biogesic",
    "name": "Biogesic tablet",
    "use": "Reduces fever and relieves minor headaches or pain.",
    "image": "assets/medicines/biogesic.jpg",
    "url":
        "https://www.mims.com/philippines/image/info/biogesic-tab-500-mg/500-mg?id=c21db070-fd09-40a0-bff2-a51d010fa679",
    "color": ["Brown"],
    "shape": "Oval",
    "form": "Tablet",
    "markings": "BIOGESIC/500"
  },
  {
    "modelLabel": "DayZinc",
    "name": "Dayzinc capsule",
    "use": "Vitamin supplement to boost immunity and growth.",
    "image": "assets/medicines/dayzinc.jpg",
    "url":
        "https://www.mims.com/philippines/image/info/dayzinc-cap?id=3ca7ca9a-715d-4ef5-ab7b-a077009a0d23",
    "color": ["Brown"],
    "shape": "Capsule",
    "form": "Capsule",
  },
  {
    "modelLabel": "Decolgen",
    "name": "Decolgen PE tablet",
    "use": "Relieves clogged nose, headache, and nasal congestion.",
    "image": "assets/medicines/decolgen.jpg",
    "url":
        "https://www.mims.com/philippines/drug/info/decolgen-forte-no-drowse-decolgen",
    "color": ["Yellow"],
    "shape": "Round",
    "form": "Tablet",
    "markings": "WESTMONT"
  },
  {
    "modelLabel": "Fish Oil",
    "name": "Omega gold softgel capsule",
    "use": "Supports heart, brain, and joint health with Omega-3.",
    "image": "assets/medicines/fishoil.jpg",
    "url":
        "https://www.mims.com/philippines/image/info/omega-gold-softgel-cap/1-200-mg?id=89304c93-e8f2-4b39-9d10-a99100dcc0fc",
    "color": ["Yellow"],
    "shape": "Oblong",
    "form": "Capsule",
  },
  {
    "modelLabel": "Kremil S",
    "name": "Kremil-S chewable tablet",
    "use": "Relieves hyperacidity, heartburn, and stomach gas.",
    "image": "assets/medicines/kremils.jpg",
    "url":
        "https://www.mims.com/philippines/image/info/kremil-s-chewable-tab?id=fa59319b-f486-4cc2-ba83-a97700da04c2",
    "color": ["Pink"],
    "shape": "Round",
    "form": "Tablet",
    "markings": "KREMIL"
  },
  {
    "modelLabel": "Medicol",
    "name": "Medicol advance softgel capsule",
    "use": "Fast relief for severe headaches, toothaches, and cramps.",
    "image": "assets/medicines/medicol.jpg",
    "url":
        "https://www.mims.com/philippines/image/info/medicol-advance-softgel-cap-200-mg/200-mg?id=d1f7fa2b-7279-47c7-a5b5-a51d011588d0",
    "color": ["Red"],
    "shape": "Oval",
    "form": "Capsule",
  },
  {
    "modelLabel": "Neozep",
    "name": "NEOZEP Forte tablet",
    "use": "Relieves runny nose, sneezing, and itchy/watery eyes.",
    "image": "assets/medicines/neozep.jpg",
    "url":
        "https://www.mims.com/philippines/drug/info/neozep-forte-neozep-non-drowsy",
    "color": ["White", "Blue"],
    "shape": "Oval",
    "form": "Tablet",
    "markings": "NEOZEP"
  },
];

// --- SHARED HOW-TO-USE INSTRUCTIONS ---
final List<Map<String, String>> appInstructions = [
  {
    "image": "assets/howto/1.jpg",
    "title": "Step 1: Main View",
    "desc": "Display the full app view. Ensure you have a pill ready for classification."
  },
  {
    "image": "assets/howto/2.jpg",
    "title": "Step 2: Main Buttons",
    "desc": "Left: Select a photo from the gallery\nCenter: Capture button for taking a photo of the pill\nRight: History button to view recent captures and analyses"
  },
  {
    "image": "assets/howto/3.jpg",
    "title": "Step 3: Top Controls",
    "desc": "Top-left: Menu button that opens the sidebar\nTop-right: Flash toggle for use in low-light conditions"
  },
  {
    "image": "assets/howto/4.jpg",
    "title": "Step 4: Evaluation",
    "desc": "Show the evaluation screen, where the selected or captured image is analyzed and the prediction result is displayed."
  },
];

// --- CAPTURE BEST-PRACTICES (separate text-only section, shown after Steps 1-4) ---
const String captureTipsTitle = "Tips for Capturing a Good Photo";
const String captureTipsText =
    "For the most reliable results, follow these tips when taking a photo:\n\n"
    "• Place the drug in the center of the camera view (enable the Center Guide in Settings to show a box).\n"
    "• Make sure the drug is brightly and evenly lit so every detail is clearly visible.\n"
    "• In a dark area, tap the flashlight button at the top-right of the camera screen.\n"
    "• Check that the drug is one of the 10 supported classes in this app.\n"
    "• Try different positions and angles if needed — a top-down view works best.\n"
    "• Keep only the drug in the frame and remove unnecessary background objects.\n\n"
    "Following these tips improves prediction reliability, because the model performs best when the drug is clearly visible and centered.";

// Reusable card that renders the capture best-practices section.
Widget buildCaptureTipsSection() {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.grey[900],
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.tealAccent.withValues(alpha: 0.5)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.tips_and_updates, color: Colors.tealAccent, size: 24),
            const SizedBox(width: 8),
            Expanded(child: Text(captureTipsTitle, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.tealAccent))),
          ],
        ),
        const SizedBox(height: 10),
        const Text(captureTipsText, style: TextStyle(fontSize: 14, height: 1.5)),
      ],
    ),
  );
}

// --- SHARED DISCLAIMER TEXT ---
const String userAgreementText = 
  "MediSina Scan — Thesis Prototype v1.0\n\n"
  "This application is a research prototype developed as part of an undergraduate thesis. It is designed to assist users in identifying 10 specific over-the-counter (OTC) medicines commonly available in the Philippines.\n\n"
  "1. Limited Classification Scope\n"
  "This application recognises only 10 OTC medicines. It cannot identify medicines outside this set and may produce incorrect results when presented with unlisted products.\n\n"
  "2. No Counterfeit or Expiry Detection\n"
  "This application does not detect counterfeit, damaged, or expired medicines. A correct classification does not confirm that a medicine is safe or authentic.\n\n"
  "3. No Object Detection\n"
  "This application does not verify whether a pill is present in the camera frame. It will attempt a classification on any image provided, including images with no medicine present.\n\n"
  "4. Not a Medical Tool\n"
  "This application is not a substitute for professional medical advice. Always verify any result with a licensed pharmacist or physician before making any medication-related decision.\n\n"
  "5. Prototype Limitations\n"
  "As a thesis prototype, this application has not undergone clinical validation and should not be used in any medical or pharmaceutical context beyond academic evaluation.\n\n"
  "By proceeding, you confirm that you have read and understood these limitations.";

List<CameraDescription> cameras = [];
bool isFirstLaunch = true;

// --- GLOBAL FONT SCALE ---
// Notifies the whole app when the user changes the font size in Settings.
final ValueNotifier<double> fontScaleNotifier = ValueNotifier<double>(1.0);

// Maps the three named font sizes to text scale factors.
const double fontScaleSmall = 0.85;
const double fontScaleMedium = 1.0;
const double fontScaleLarge = 1.2;

// Side length of the centered camera guide box, as a fraction of the shorter
// dimension. The captured image is cropped to this same centered square before
// being sent to the model, so the overlay and the crop stay in sync.
const double centerGuideFraction = 0.7;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // NOTE: camera enumeration is deferred until after the permission check
  // (see _setupCamera) so nothing touches the camera before we verify access.

  final prefs = await SharedPreferences.getInstance();
  isFirstLaunch = prefs.getBool('first_time') ?? true;
  fontScaleNotifier.value = prefs.getDouble('font_scale') ?? fontScaleMedium;

  runApp(const MedicineApp());
}

class MedicineApp extends StatelessWidget {
  const MedicineApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<double>(
      valueListenable: fontScaleNotifier,
      builder: (context, scale, _) {
        return MaterialApp(
          title: 'Medisina Scan',
          theme: ThemeData(primarySwatch: Colors.teal, brightness: Brightness.dark),
          builder: (context, child) {
            final mediaQuery = MediaQuery.of(context);
            return MediaQuery(
              data: mediaQuery.copyWith(textScaler: TextScaler.linear(scale)),
              child: child!,
            );
          },
          home: isFirstLaunch ? const OnboardingScreen() : const CameraScreen(),
        );
      },
    );
  }
}

// --- ONBOARDING SCREEN ---
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  
  bool checkCamera = false; 
  bool checkTerms = false;
  bool checkGallery = false; 
  bool checkHistory = false; 
  int _howToIndex = 0;

  void _goToInstructions() {
    _pageController.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
  }

  void _nextHowTo() {
    if (_howToIndex < appInstructions.length - 1) {
      setState(() { _howToIndex++; });
    }
  }

  void _prevHowTo() {
    if (_howToIndex > 0) {
      setState(() { _howToIndex--; });
    }
  }

  void _completeOnboarding() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('first_time', false);
    await prefs.setBool('save_to_gallery', checkGallery); 
    await prefs.setBool('save_history', checkHistory); 
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const CameraScreen()));
  }

  @override
  Widget build(BuildContext context) {
    bool requiredChecked = checkCamera && checkTerms;
    bool isLastStep = _howToIndex == appInstructions.length - 1;

    return Scaffold(
      appBar: AppBar(title: const Text("Welcome to Medisina Scan"), automaticallyImplyLeading: false),
      body: PageView(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(), 
        children: [
          // PAGE 1: AGREEMENT
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.health_and_safety, size: 60, color: Colors.tealAccent), const SizedBox(height: 15),
                const Text("Terms & User Agreement", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(15), 
                  decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.teal)), 
                  child: const Text(userAgreementText, style: TextStyle(fontSize: 14, height: 1.5), textAlign: TextAlign.justify)
                ), 
                const SizedBox(height: 25),
                
                const Text("Required Permissions", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.tealAccent)), 
                const SizedBox(height: 5),
                CheckboxListTile(title: const Text("I allow the app to access the Camera.", style: TextStyle(fontSize: 14)), value: checkCamera, activeColor: Colors.tealAccent, onChanged: (val) => setState(() => checkCamera = val!)),
                CheckboxListTile(title: const Text("I accept the Terms and Agreement stated above.", style: TextStyle(fontSize: 14)), value: checkTerms, activeColor: Colors.tealAccent, onChanged: (val) => setState(() => checkTerms = val!)),
                
                const Divider(height: 30),

                const Text("Optional Settings", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey)), 
                const SizedBox(height: 5),
                CheckboxListTile(title: const Text("Automatically save captured photos to the gallery.", style: TextStyle(fontSize: 14)), value: checkGallery, activeColor: Colors.tealAccent, onChanged: (val) => setState(() => checkGallery = val!)),
                CheckboxListTile(title: const Text("Save a history of my captured results.", style: TextStyle(fontSize: 14)), value: checkHistory, activeColor: Colors.tealAccent, onChanged: (val) => setState(() => checkHistory = val!)),
                
                const SizedBox(height: 30),
                SizedBox(width: double.infinity, height: 50, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: requiredChecked ? Colors.tealAccent.shade700 : Colors.grey), onPressed: requiredChecked ? _goToInstructions : null, child: const Text("Next", style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold))))
              ],
            ),
          ),
          
          // PAGE 2: HOW TO USE
          SingleChildScrollView(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                const Text("How to Use Medisina Scan", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.tealAccent)),
                const SizedBox(height: 10),
                Text("Step ${_howToIndex + 1} of ${appInstructions.length}", style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white70)),
                const SizedBox(height: 15),
                Container(
                  height: 300,
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.teal.withValues(alpha: 0.3)),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Image.asset(
                      appInstructions[_howToIndex]["image"]!,
                      fit: BoxFit.contain,
                      width: double.infinity,
                      errorBuilder: (context, error, stackTrace) => Container(
                        color: Colors.grey[800],
                        child: const Center(child: Icon(Icons.image_not_supported, size: 60, color: Colors.grey)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(appInstructions[_howToIndex]["title"]!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.tealAccent)),
                const SizedBox(height: 10),
                Text(appInstructions[_howToIndex]["desc"]!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, height: 1.5)),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton.icon(
                      onPressed: _howToIndex > 0 ? _prevHowTo : null,
                      icon: const Icon(Icons.arrow_back),
                      label: const Text("Back"),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[500]),
                    ),
                    ElevatedButton(
                      onPressed: _howToIndex < appInstructions.length - 1 ? _nextHowTo : null,
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[500]),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text("Next"),
                          SizedBox(width: 5),
                          Icon(Icons.arrow_forward),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 25),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: isLastStep ? Colors.tealAccent.shade700 : Colors.grey),
                    onPressed: isLastStep ? _completeOnboarding : null,
                    child: const Text("I Understand & Start", style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold))
                  )
                ),
                const SizedBox(height: 25),
                const Divider(),
                const SizedBox(height: 15),
                // Separate text-only group (best practices), shown after the button.
                buildCaptureTipsSection(),
                const SizedBox(height: 10),
              ],
            ),
          )
        ],
      ),
    );
  }
}

// --- MAIN CAMERA SCREEN ---
class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> with WidgetsBindingObserver {
  CameraController? _controller;
  final Classifier _classifier = Classifier();
  final ImagePicker _picker = ImagePicker();
  
  bool _isCameraInitialized = false;
  FlashMode _flashMode = FlashMode.off;
  bool _isAnalyzing = false;
  bool _centerGuide = false;
  bool _cameraDenied = false;
  bool _cameraPermanentlyDenied = false;

  List<Map<String, dynamic>> predictionHistory = [];

  @override void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _classifier.loadModel();
    _initCamera();
    _loadHistory();
    _loadCameraPrefs();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // When coming back to the app (e.g. after enabling the permission in
    // Settings), retry initialization if the camera isn't ready yet — without
    // forcing a new prompt when permission is already granted.
    if (state == AppLifecycleState.resumed && !_isCameraInitialized) {
      _initCamera();
    }
  }

  Future<void> _loadCameraPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() { _centerGuide = prefs.getBool('center_guide') ?? false; });
  }
  
  @override void dispose() { WidgetsBinding.instance.removeObserver(this); _controller?.dispose(); _classifier.close(); super.dispose(); }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyString = prefs.getString('scan_history');
    if (historyString != null) {
      List<dynamic> decoded = json.decode(historyString);
      setState(() { predictionHistory = decoded.map((e) => Map<String, dynamic>.from(e)).toList(); });
    }
  }

  Future<void> _initCamera() async {
    // Check the current status FIRST so an already-granted permission never
    // triggers another prompt on launch.
    PermissionStatus status = await Permission.camera.status;

    // Only ask when it has not been granted and is not permanently blocked.
    if (!status.isGranted && !status.isPermanentlyDenied && !status.isRestricted) {
      status = await Permission.camera.request();
    }

    if (!mounted) return;

    if (status.isGranted) {
      await _setupCamera();
    } else {
      // Denied or permanently denied: surface a clear in-app message instead
      // of an endless loading spinner.
      setState(() {
        _isCameraInitialized = false;
        _cameraDenied = true;
        _cameraPermanentlyDenied = status.isPermanentlyDenied || status.isRestricted;
      });
    }
  }

  // Only called once camera permission is confirmed granted. Camera hardware is
  // enumerated here (not in main) so no camera access happens before the check.
  Future<void> _setupCamera() async {
    try {
      if (cameras.isEmpty) {
        cameras = await availableCameras();
      }
      if (cameras.isEmpty) return; // No camera hardware available.
      _controller = CameraController(cameras[0], ResolutionPreset.medium, enableAudio: false);
      await _controller!.initialize();
      if (!mounted) return;
      setState(() { _isCameraInitialized = true; _cameraDenied = false; _cameraPermanentlyDenied = false; });
    } catch (e) {
      print("Camera init error: $e");
    }
  }

  // Re-run the permission flow when the user taps "Grant Permission", or open
  // the OS settings page when the permission is permanently denied.
  Future<void> _handlePermissionAction() async {
    if (_cameraPermanentlyDenied) {
      await openAppSettings();
    } else {
      await _initCamera();
    }
  }

  void _toggleFlash() async {
    if (_controller == null) return;
    FlashMode nextMode = _flashMode == FlashMode.off ? FlashMode.torch : FlashMode.off;
    await _controller!.setFlashMode(nextMode); setState(() { _flashMode = nextMode; });
  }

  Future<void> _takePicture() async {
    if (!_isCameraInitialized || _controller == null || _controller!.value.isTakingPicture) return;
    try {
      final XFile photo = await _controller!.takePicture();
      final prefs = await SharedPreferences.getInstance();
      bool shouldSaveToGallery = prefs.getBool('save_to_gallery') ?? false;

      if (shouldSaveToGallery) {
        await GallerySaver.saveImage(photo.path);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Saved to Gallery"), duration: Duration(seconds: 1)));
      }
      _processImage(File(photo.path));
    } catch (e) { print("Error taking picture: $e"); }
  }

  Future<void> _pickFromGallery() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) _processImage(File(image.path));
  }

  Future<void> _processImage(File imageFile) async {
    setState(() { _isAnalyzing = true; });

    // --- UPDATED: MEASURE INFERENCE TIME ---
    final stopwatch = Stopwatch()..start();
    final result = await _classifier.classifyImage(imageFile);
    stopwatch.stop();
    final int inferenceTimeMs = stopwatch.elapsedMilliseconds;

    final prefs = await SharedPreferences.getInstance();
    bool shouldSaveHistory = prefs.getBool('save_history') ?? false;

    if (!mounted) return;

    setState(() {
      _isAnalyzing = false;
      if (result != null) {
        final medMap = medicineDatabase.firstWhere((m) => m['modelLabel'] == result['label'], orElse: () => <String, dynamic>{});
        String displayLabel = medMap.isNotEmpty ? medMap['name']! : result['label'];
        String timeString = "${(inferenceTimeMs / 1000).toStringAsFixed(2)} sec";

        if (shouldSaveHistory) {
          predictionHistory.insert(0, {
            'id': DateTime.now().millisecondsSinceEpoch.toString(), 
            'imagePath': imageFile.path,
            'modelLabel': result['label'], 
            'displayLabel': displayLabel, 
            'confidence': result['confidence'], 
            'inferenceTime': timeString, // Save time to history
            'time': DateTime.now().toIso8601String()
          });
          prefs.setString('scan_history', json.encode(predictionHistory));
        }
        
        _showResultDialog(imageFile, result['label'], result['confidence'], timeString);
      } else { 
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Classification failed. Try again.")));
      }
    });
  }

  void _showResultDialog(File image, String modelLabel, String confidence, String inferenceTime) {
    final medMap = medicineDatabase.firstWhere((m) => m['modelLabel'] == modelLabel, orElse: () => <String, dynamic>{});
    String? refImage = medMap.isNotEmpty ? medMap['image'] : null;
    String displayTitle = medMap.isNotEmpty ? medMap['name']! : modelLabel;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(displayTitle, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(children: [
              Expanded(child: Column(children: [const Text("Captured Image", style: TextStyle(fontSize: 12, color: Colors.tealAccent)), const SizedBox(height: 5), ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(image, height: 120, width: double.infinity, fit: BoxFit.contain))])),
              const SizedBox(width: 10), const Icon(Icons.compare_arrows, color: Colors.grey), const SizedBox(width: 10),
              Expanded(child: Column(children: [const Text("MIMS Reference", style: TextStyle(fontSize: 12, color: Colors.tealAccent)), const SizedBox(height: 5), ClipRRect(borderRadius: BorderRadius.circular(8), child: refImage != null ? Image.asset(refImage, height: 120, width: double.infinity, fit: BoxFit.contain) : Container(height: 120, color: Colors.grey[800], child: const Icon(Icons.image_not_supported)))])),
            ]), const SizedBox(height: 20),
            
            // --- UPDATED: DISPLAY TIME NEXT TO CONFIDENCE ---
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Confidence: $confidence", style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(width: 15),
                Text("Time: $inferenceTime", style: const TextStyle(fontSize: 16, color: Colors.tealAccent)),
              ],
            ),
            
            Container(margin: const EdgeInsets.only(top: 15), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.orange.withValues(alpha: 0.5))), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline, color: Colors.orangeAccent, size: 20), SizedBox(width: 8), Expanded(child: Text("This model may still make mistakes. Please verify the captured image with the provided image reference.", style: TextStyle(color: Colors.orangeAccent, fontSize: 12, fontStyle: FontStyle.italic)))]))
          ],
        ),
        actions: [ 
          TextButton(onPressed: () { Navigator.pop(context); if (medMap.isNotEmpty) { Navigator.push(context, MaterialPageRoute(builder: (context) => MedicineDetailScreen(medicine: medMap))); } }, child: const Text("View Details", style: TextStyle(color: Colors.tealAccent))),
          ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text("OK")) 
        ],
      )
    );
  }

  // Shown when the camera isn't ready: a loading spinner while initializing, or
  // a clear permission message (with an action) when access was denied.
  Widget _buildCameraPlaceholder() {
    if (!_cameraDenied) {
      return const Center(child: CircularProgressIndicator());
    }
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.no_photography, size: 70, color: Colors.tealAccent),
            const SizedBox(height: 20),
            Text(
              _cameraPermanentlyDenied
                  ? "Camera access is turned off. Please enable the Camera permission in your device Settings to scan medicines."
                  : "Camera access is needed to scan medicines. Please grant the Camera permission to continue.",
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[500]),
              onPressed: _handlePermissionAction,
              icon: Icon(_cameraPermanentlyDenied ? Icons.settings : Icons.camera_alt, color: Colors.white),
              label: Text(
                _cameraPermanentlyDenied ? "Open Settings" : "Grant Permission",
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Centered square overlay that mirrors the crop applied to captured images.
  // Outline only: no fill, shading, or overlay inside the box so the framed
  // area stays fully visible. The hint label sits outside (below) the box.
  Widget _buildCenterGuide() {
    return IgnorePointer(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final double side = (constraints.maxWidth < constraints.maxHeight ? constraints.maxWidth : constraints.maxHeight) * centerGuideFraction;
          return Stack(
            children: [
              Center(
                child: Container(
                  width: side,
                  height: side,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(color: Colors.tealAccent, width: 3),
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              // Hint placed just below the box, outside its bounds.
              Center(
                child: Transform.translate(
                  offset: Offset(0, side / 2 + 24),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)),
                    child: const Text("Place the drug inside the box", style: TextStyle(color: Colors.tealAccent, fontSize: 12, fontWeight: FontWeight.bold)),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent, elevation: 0,
        toolbarHeight: 88,
        leadingWidth: 92,
        leading: Builder(builder: (context) => Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.black54,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.6), blurRadius: 14, spreadRadius: 3, offset: const Offset(0, 4))],
          ),
          child: IconButton(
            iconSize: 46,
            padding: const EdgeInsets.all(12),
            constraints: const BoxConstraints(),
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        )),
        actions: [
          if (_isCameraInitialized) Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.black54,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.6), blurRadius: 14, spreadRadius: 3, offset: const Offset(0, 4))],
            ),
            child: IconButton(
              iconSize: 46,
              padding: const EdgeInsets.all(12),
              constraints: const BoxConstraints(),
              icon: Icon(_flashMode == FlashMode.torch ? Icons.flash_on : Icons.flash_off, color: Colors.white),
              onPressed: _toggleFlash,
            ),
          ),
          const SizedBox(width: 12)
        ]
      ),
      drawer: Drawer(
        child: Column(
          children: [
            DrawerHeader(
              padding: EdgeInsets.zero, decoration: const BoxDecoration(color: Colors.teal),
              child: Stack(children: [Positioned(top: 10, right: 10, child: IconButton(icon: const Icon(Icons.close, color: Colors.white, size: 28), onPressed: () => Navigator.pop(context))), const Positioned(bottom: 15, left: 15, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Medisina Scan', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)), Text('Thesis Prototype', style: TextStyle(color: Colors.white70, fontSize: 14))]))]),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  ListTile(leading: const Icon(Icons.menu_book), title: const Text('Medicine Directory'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (context) => const MedicineDirectoryScreen())); }),
                  ListTile(leading: const Icon(Icons.settings), title: const Text('Settings'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (context) => const SettingsScreen())).then((_) => _loadCameraPrefs()); }),
                  const Divider(),
                  ListTile(leading: const Icon(Icons.info_outline), title: const Text('Application Details'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (context) => const AppDetailsScreen())); }),
                  ListTile(leading: const Icon(Icons.help_outline), title: const Text('How to Use'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (context) => const HowToUseScreen())); }),
                  ListTile(leading: const Icon(Icons.rocket_launch), title: const Text('Future Works'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (context) => const FutureWorksScreen())); }),
                  ListTile(leading: const Icon(Icons.mail), title: const Text('Suggestions & Contact'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (context) => const ContactScreen())); }),
                  ListTile(leading: const Icon(Icons.gavel), title: const Text('Terms and Agreement'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (context) => const TermsScreen())); }),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          if (_isCameraInitialized) SizedBox.expand(child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: _controller!.value.previewSize?.height ?? 1, height: _controller!.value.previewSize?.width ?? 1, child: CameraPreview(_controller!)))) else _buildCameraPlaceholder(),
          if (_isCameraInitialized && _centerGuide) _buildCenterGuide(),
          if (_isAnalyzing) Container(color: Colors.black.withValues(alpha: 0.7), child: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [CircularProgressIndicator(color: Colors.tealAccent, strokeWidth: 5), SizedBox(height: 20), Text("Analyzing Pill...", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 1.2))]))),
          
          SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end, 
              children: [
                Container(
                  padding: const EdgeInsets.only(bottom: 30, top: 10), color: Colors.black.withValues(alpha: 0.5), 
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly, 
                    children: [
                      IconButton(icon: const Icon(Icons.photo_library, color: Colors.white, size: 35), onPressed: _pickFromGallery), 
                      GestureDetector(onTap: _takePicture, child: Container(height: 70, width: 70, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 4), color: Colors.tealAccent.withValues(alpha: 0.8)), child: const Icon(Icons.camera, color: Colors.white, size: 40))), 
                      IconButton(icon: const Icon(Icons.history, color: Colors.white, size: 35), onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (context) => HistoryScreen(history: predictionHistory))); })
                    ]
                  )
                )
              ]
            )
          ),
        ],
      ),
    );
  }
}

// --- DIRECTORY SCREEN ---
class MedicineDirectoryScreen extends StatefulWidget { const MedicineDirectoryScreen({super.key}); @override State<MedicineDirectoryScreen> createState() => _MedicineDirectoryScreenState(); }
class _MedicineDirectoryScreenState extends State<MedicineDirectoryScreen> {
  String _searchQuery = ""; String? _selectedColor; String? _selectedShape; String? _selectedForm; bool? _selectedMarkings;
  final List<String> _colors = ['All', 'Cream', 'Orange', 'Blue', 'Brown', 'Yellow', 'Pink', 'Red', 'White'];
  final List<String> _shapes = ['All', 'Round', 'Oblong', 'Oval', 'Capsule'];
  final List<String> _forms = ['All', 'Capsule', 'Lozenge', 'Tablet'];

  List<Map<String, dynamic>> get _filteredMedicines {
    return medicineDatabase.where((med) {
      final nameMatches = med['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
      final labelMatches = med['modelLabel'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
      if (!nameMatches && !labelMatches) return false;
      if (_selectedColor != null && _selectedColor != 'All' && !List<String>.from(med['color']).contains(_selectedColor)) return false;
      if (_selectedShape != null && _selectedShape != 'All' && med['shape'] != _selectedShape) return false;
      if (_selectedForm != null && _selectedForm != 'All' && med['form'] != _selectedForm) return false;
      if (_selectedMarkings != null && (med['markings'] != null && med['markings'].toString().isNotEmpty) != _selectedMarkings) return false;
      return true;
    }).toList();
  }

  void _showFilterDialog() { showDialog(context: context, builder: (context) { return StatefulBuilder(builder: (context, setDialogState) { return AlertDialog(title: const Text("Filter Medicines", style: TextStyle(color: Colors.tealAccent)), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [const Text("Color", style: TextStyle(fontWeight: FontWeight.bold)), DropdownButton<String>(isExpanded: true, value: _selectedColor ?? 'All', items: _colors.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (val) { setDialogState(() => _selectedColor = val); setState(() => _selectedColor = val); }), const SizedBox(height: 10), const Text("Shape", style: TextStyle(fontWeight: FontWeight.bold)), DropdownButton<String>(isExpanded: true, value: _selectedShape ?? 'All', items: _shapes.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (val) { setDialogState(() => _selectedShape = val); setState(() => _selectedShape = val); }), const SizedBox(height: 10), const Text("Form", style: TextStyle(fontWeight: FontWeight.bold)), DropdownButton<String>(isExpanded: true, value: _selectedForm ?? 'All', items: _forms.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(), onChanged: (val) { setDialogState(() => _selectedForm = val); setState(() => _selectedForm = val); }), const SizedBox(height: 10), const Text("Markings/Imprints", style: TextStyle(fontWeight: FontWeight.bold)), DropdownButton<String>(isExpanded: true, value: _selectedMarkings == null ? 'All' : (_selectedMarkings! ? 'Yes' : 'No'), items: ['All', 'Yes', 'No'].map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(), onChanged: (val) { bool? newValue = val == 'Yes' ? true : (val == 'No' ? false : null); setDialogState(() => _selectedMarkings = newValue); setState(() => _selectedMarkings = newValue); })])), actions: [TextButton(onPressed: () { setDialogState(() { _selectedColor = null; _selectedShape = null; _selectedForm = null; _selectedMarkings = null; }); setState(() { _selectedColor = null; _selectedShape = null; _selectedForm = null; _selectedMarkings = null; }); }, child: const Text("Clear Filters", style: TextStyle(color: Colors.redAccent))), ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text("Apply"))]); }); }); }

  @override Widget build(BuildContext context) { final results = _filteredMedicines; return Scaffold(appBar: AppBar(title: const Text('Medicine Directory'), actions: [IconButton(icon: const Icon(Icons.filter_list, color: Colors.tealAccent), onPressed: _showFilterDialog), IconButton(icon: const Icon(Icons.info_outline, color: Colors.tealAccent), onPressed: () => showDialog(context: context, builder: (context) => AlertDialog(title: const Row(children: [Icon(Icons.menu_book, color: Colors.tealAccent), SizedBox(width: 10), Text("Reference Source")]), content: const Text("The medicine images and pharmacological details provided in this directory are sourced from MIMS Philippines.", textAlign: TextAlign.justify), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("Close"))])))],), body: Column(children: [Padding(padding: const EdgeInsets.all(10.0), child: TextField(decoration: InputDecoration(hintText: "Search for a medicine...", prefixIcon: const Icon(Icons.search, color: Colors.tealAccent), filled: true, fillColor: Colors.grey[900], border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none)), onChanged: (value) => setState(() => _searchQuery = value))), Expanded(child: results.isEmpty ? const Center(child: Text("No medicines match your filters.")) : ListView.builder(itemCount: results.length, itemBuilder: (context, index) { final med = results[index]; return Card(margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), child: ListTile(leading: ClipRRect(borderRadius: BorderRadius.circular(5), child: Container(width: 55, height: 55, color: Colors.white, child: Image.asset(med['image']!, fit: BoxFit.contain, errorBuilder: (context, error, stackTrace) => const Icon(Icons.medication, color: Colors.teal)))), title: Text(med['name']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)), subtitle: Text(med['use']!, maxLines: 1, overflow: TextOverflow.ellipsis), trailing: const Icon(Icons.arrow_forward_ios, size: 16), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (context) => MedicineDetailScreen(medicine: med))); })); }))])); } }

// --- HOW TO USE SCREEN (MENU VERSION) ---
class HowToUseScreen extends StatefulWidget {
  const HowToUseScreen({super.key});
  @override
  State<HowToUseScreen> createState() => _HowToUseScreenState();
}

class _HowToUseScreenState extends State<HowToUseScreen> {
  int _currentIndex = 0;

  void _nextStep() {
    if (_currentIndex < appInstructions.length - 1) {
      setState(() { _currentIndex++; });
    }
  }

  void _prevStep() {
    if (_currentIndex > 0) {
      setState(() { _currentIndex--; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("How to Use Medisina Scan")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Text("Step ${_currentIndex + 1} of ${appInstructions.length}", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.tealAccent)),
            const SizedBox(height: 20),
            Container(
              height: 320,
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.teal.withValues(alpha: 0.3)),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.asset(
                  appInstructions[_currentIndex]["image"]!,
                  fit: BoxFit.contain,
                  width: double.infinity,
                  errorBuilder: (context, error, stackTrace) => Container(
                    color: Colors.grey[800],
                    child: const Center(child: Icon(Icons.image_not_supported, size: 60, color: Colors.grey)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(appInstructions[_currentIndex]["title"]!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.tealAccent)),
            const SizedBox(height: 10),
            Text(appInstructions[_currentIndex]["desc"]!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, height: 1.5)),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton.icon(
                  onPressed: _currentIndex > 0 ? _prevStep : null,
                  icon: const Icon(Icons.arrow_back),
                  label: const Text("Back"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[500]),
                ),
                ElevatedButton(
                  onPressed: _currentIndex < appInstructions.length - 1 ? _nextStep : null,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[500]),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text("Next"),
                      SizedBox(width: 5),
                      Icon(Icons.arrow_forward),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            const Divider(),
            const SizedBox(height: 15),
            // Separate text-only group (best practices), independent of Steps 1-4.
            buildCaptureTipsSection(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class MedicineDetailScreen extends StatelessWidget { final Map<String, dynamic> medicine; const MedicineDetailScreen({super.key, required this.medicine}); Future<void> _launchMimsUrl(BuildContext context) async { final Uri url = Uri.parse(medicine['url']!); if (!await launchUrl(url, mode: LaunchMode.externalApplication)) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open the webpage.'))); } } @override Widget build(BuildContext context) { return Scaffold(appBar: AppBar(title: const Text("Details")), body: SingleChildScrollView(padding: const EdgeInsets.all(20.0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Center(child: Text(medicine['name']!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.tealAccent))), const SizedBox(height: 20), Center(child: ClipRRect(borderRadius: BorderRadius.circular(15), child: InteractiveViewer(panEnabled: true, boundaryMargin: const EdgeInsets.all(20), minScale: 0.8, maxScale: 4.0, child: Image.asset(medicine['image']!, height: 250, width: double.infinity, fit: BoxFit.contain, errorBuilder: (context, error, stackTrace) => Container(height: 250, color: Colors.grey[800], child: const Center(child: Icon(Icons.image_not_supported, size: 50, color: Colors.grey))))))), const SizedBox(height: 30), const Text("Physical Attributes", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.tealAccent)), const Divider(), Row(children: [const Icon(Icons.palette, size: 18, color: Colors.grey), const SizedBox(width: 8), Text("Color: ${(medicine['color'] as List).join(', ')}")]), const SizedBox(height: 5), Row(children: [const Icon(Icons.category, size: 18, color: Colors.grey), const SizedBox(width: 8), Text("Shape: ${medicine['shape']}")]), const SizedBox(height: 5), Row(children: [const Icon(Icons.medication, size: 18, color: Colors.grey), const SizedBox(width: 8), Text("Form: ${medicine['form']}")]), if (medicine['markings'] != null && medicine['markings'].toString().trim().isNotEmpty) ...[const SizedBox(height: 5), Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.fingerprint, size: 18, color: Colors.grey), const SizedBox(width: 8), Expanded(child: Text("Markings/Imprint: ${medicine['markings']}"))])], const SizedBox(height: 20), const Text("Pharmacological Details", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.tealAccent)), const Divider(), const SizedBox(height: 10), const Text("Primary Use:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 5), Text(medicine['use']!, style: const TextStyle(fontSize: 16, height: 1.5)), const SizedBox(height: 30), SizedBox(width: double.infinity, height: 50, child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[500]), onPressed: () => _launchMimsUrl(context), icon: const Icon(Icons.open_in_browser, color: Colors.white), label: const Text("More Info on MIMS", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))))]))); } }

class HistoryScreen extends StatefulWidget { 
  final List<Map<String, dynamic>> history; 
  const HistoryScreen({super.key, required this.history}); 
  @override State<HistoryScreen> createState() => _HistoryScreenState(); 
}

class _HistoryScreenState extends State<HistoryScreen> {
  bool _gallerySaveEnabled = true; 
  bool _historySaveEnabled = true;
  Set<String> _selectedIds = {}; 

  @override void initState() { super.initState(); _loadSettings(); }

  void _loadSettings() async { 
    final prefs = await SharedPreferences.getInstance(); 
    setState(() { 
      _gallerySaveEnabled = prefs.getBool('save_to_gallery') ?? false; 
      _historySaveEnabled = prefs.getBool('save_history') ?? false; 
    }); 
  }

  void _toggleSelection(String id) {
    setState(() {
      if (_selectedIds.contains(id)) {
        _selectedIds.remove(id);
      } else {
        _selectedIds.add(id);
      }
    });
  }

  void _toggleSelectAll(bool? value) {
    setState(() {
      if (value == true) {
        _selectedIds = widget.history.map((e) => e['id'].toString()).toSet();
      } else {
        _selectedIds.clear();
      }
    });
  }

  void _deleteSelected() {
    if (_selectedIds.isEmpty) return;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Delete Selected"), 
        content: Text("Are you sure you want to delete ${_selectedIds.length} item(s)?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async { 
              setState(() {
                widget.history.removeWhere((item) => _selectedIds.contains(item['id'].toString()));
                _selectedIds.clear();
              }); 
              final prefs = await SharedPreferences.getInstance();
              await prefs.setString('scan_history', json.encode(widget.history)); 
              if(mounted) Navigator.pop(context); 
            }, 
            child: const Text("Delete", style: TextStyle(color: Colors.white))
          )
        ],
      )
    );
  }

  @override Widget build(BuildContext context) {
    bool allSelected = widget.history.isNotEmpty && _selectedIds.length == widget.history.length;
    bool hasSelection = _selectedIds.isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Recent Scans'),
        actions: [
          if (!_gallerySaveEnabled) IconButton(icon: const Icon(Icons.no_photography, color: Colors.orange), tooltip: "Gallery Saving Disabled", onPressed: () { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Gallery Saving is disabled in Settings."))); }),
          if (!_historySaveEnabled) IconButton(icon: const Icon(Icons.history_toggle_off, color: Colors.orange), tooltip: "History Saving Disabled", onPressed: () { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("History Saving is disabled in Settings."))); }),
          
          if (widget.history.isNotEmpty) ...[
            Row(
              children: [
                const Text("All", style: TextStyle(fontSize: 14)),
                Checkbox(value: allSelected, onChanged: _toggleSelectAll, activeColor: Colors.tealAccent),
              ],
            ),
            IconButton(
              icon: Icon(Icons.delete, color: hasSelection ? Colors.redAccent : Colors.grey), 
              onPressed: hasSelection ? _deleteSelected : null, 
              tooltip: "Delete Selected"
            )
          ]
        ],
      ),
      body: widget.history.isEmpty 
        ? const Center(child: Text("No history yet. Scan some medicines!")) 
        : ListView.builder(
            itemCount: widget.history.length, 
            itemBuilder: (context, index) { 
              final item = widget.history[index]; 
              bool isSelected = _selectedIds.contains(item['id'].toString());
              String inferenceTime = item['inferenceTime'] ?? 'N/A'; // Fallback for old history items

              final medMap = medicineDatabase.firstWhere((m) => m['modelLabel'] == item['modelLabel'], orElse: () => <String, dynamic>{});
              String? refImage = medMap.isNotEmpty ? medMap['image'] : null;

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), 
                child: InkWell(
                  onTap: () { if (medMap.isNotEmpty) { Navigator.push(context, MaterialPageRoute(builder: (context) => MedicineDetailScreen(medicine: medMap))); } else { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Medicine details not found."))); } }, 
                  child: Padding(
                    padding: const EdgeInsets.all(15.0), 
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(item['displayLabel'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.tealAccent)), 
                                  const SizedBox(height: 5), 
                                  // --- UPDATED: DISPLAY TIME IN HISTORY ---
                                  Text("Confidence: ${item['confidence']}  •  Time: $inferenceTime", style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)), 
                                ],
                              ),
                            ),
                            Checkbox(
                              value: isSelected,
                              onChanged: (bool? value) => _toggleSelection(item['id'].toString()),
                              activeColor: Colors.tealAccent,
                            ),
                          ],
                        ),
                        const SizedBox(height: 15),
                        Row(children: [
                          Expanded(child: Column(children: [const Text("Captured Image", style: TextStyle(fontSize: 12, color: Colors.grey)), const SizedBox(height: 5), ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(item['imagePath']), height: 100, width: double.infinity, fit: BoxFit.contain, errorBuilder: (context, error, stackTrace) => Container(height: 100, color: Colors.grey[800], child: const Icon(Icons.broken_image))))])),
                          const SizedBox(width: 10), const Icon(Icons.compare_arrows, color: Colors.grey), const SizedBox(width: 10),
                          Expanded(child: Column(children: [const Text("MIMS Reference", style: TextStyle(fontSize: 12, color: Colors.grey)), const SizedBox(height: 5), ClipRRect(borderRadius: BorderRadius.circular(8), child: refImage != null ? Image.asset(refImage, height: 100, width: double.infinity, fit: BoxFit.contain) : Container(height: 100, color: Colors.grey[800], child: const Icon(Icons.image_not_supported)))]))
                        ]),
                        const SizedBox(height: 15),
                        
                        Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.orange.withValues(alpha: 0.5))), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline, color: Colors.orangeAccent, size: 20), SizedBox(width: 8), Expanded(child: Text("This model may still make mistakes. Please verify the captured image with the provided image reference.", style: TextStyle(color: Colors.orangeAccent, fontSize: 12, fontStyle: FontStyle.italic)))]))
                      ]
                    )
                  )
                )
              ); 
            }
          ),
    );
  }
}

class FutureWorksScreen extends StatelessWidget { 
  const FutureWorksScreen({super.key}); 
  @override Widget build(BuildContext context) { 
    return Scaffold(
      appBar: AppBar(title: const Text("Future Works")), 
      body: Padding(
        padding: const EdgeInsets.all(20.0), 
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, 
          children: [
            const Text("Roadmap & Upgrades", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.tealAccent)), 
            const SizedBox(height: 20), 
            const Text("This thesis prototype is just the beginning. The development roadmap for Medisina Scan includes the following planned features:", style: TextStyle(fontSize: 16, height: 1.5)), 
            const SizedBox(height: 20), 
            ListTile(leading: const Icon(Icons.apple, color: Colors.teal), title: const Text("iOS Support", style: TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text("Expanding compatibility to Apple devices by publishing an official iOS release.")), 
            const Divider(), 
            ListTile(leading: const Icon(Icons.language, color: Colors.teal), title: const Text("Official Download Website", style: TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text("A dedicated portal for updates, documentation, and downloading the latest APK.")), 
            const Divider(), 
            ListTile(leading: const Icon(Icons.medication, color: Colors.teal), title: const Text("Expanded Directory", style: TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text("Scaling the AI model to classify beyond the initial 10 selected medicines, encompassing a wider range of OTC drugs.")), 
            const Divider(), 
            ListTile(leading: const Icon(Icons.cloud_sync, color: Colors.teal), title: const Text("Cloud-Based Classification", style: TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text("Migrating the inference engine to the cloud to reduce app size, improve speed, and allow seamless model updates."))
          ]
        )
      )
    ); 
  } 
}

class ContactScreen extends StatelessWidget { const ContactScreen({super.key}); @override Widget build(BuildContext context) { return Scaffold(appBar: AppBar(title: const Text("Suggestions & Contact")), body: Padding(padding: const EdgeInsets.all(20.0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.handshake, size: 60, color: Colors.tealAccent), const SizedBox(height: 20), const Text("Support the Project", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 15), const Text("Are you interested in supporting the development of Medisina Scan or collaborating on future updates?\n\nPlease note: The source code for this application is strictly for academic purposes and is NOT available for purchase.\n\nWe would love to hear your suggestions and feedback to help improve this medical classification tool.", style: TextStyle(fontSize: 16, height: 1.5), textAlign: TextAlign.justify), const SizedBox(height: 30), Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.teal)), child: const Column(children: [ListTile(leading: Icon(Icons.email, color: Colors.tealAccent), title: Text("Email Us"), subtitle: Text("ncbulio95@gmail.com"))]))]))); } }

class SettingsScreen extends StatefulWidget { const SettingsScreen({super.key}); @override State<SettingsScreen> createState() => _SettingsScreenState(); }
class _SettingsScreenState extends State<SettingsScreen> {
  bool _saveToGallery = false; bool _saveHistory = false; bool _centerGuide = false;
  double _fontScale = fontScaleMedium;
  @override void initState() { super.initState(); _loadSettings(); }
  void _loadSettings() async { final prefs = await SharedPreferences.getInstance(); setState(() { _saveToGallery = prefs.getBool('save_to_gallery') ?? false; _saveHistory = prefs.getBool('save_history') ?? false; _centerGuide = prefs.getBool('center_guide') ?? false; _fontScale = prefs.getDouble('font_scale') ?? fontScaleMedium; }); }
  void _toggleGallerySave(bool value) async { final prefs = await SharedPreferences.getInstance(); await prefs.setBool('save_to_gallery', value); setState(() { _saveToGallery = value; }); }
  void _toggleHistorySave(bool value) async { final prefs = await SharedPreferences.getInstance(); await prefs.setBool('save_history', value); setState(() { _saveHistory = value; }); }
  void _toggleCenterGuide(bool value) async { final prefs = await SharedPreferences.getInstance(); await prefs.setBool('center_guide', value); setState(() { _centerGuide = value; }); }

  // Slider works on a 0-2 index; map it to the named scale factors.
  static const List<double> _scaleSteps = [fontScaleSmall, fontScaleMedium, fontScaleLarge];
  static const List<String> _scaleLabels = ["Small", "Medium", "Larger"];

  int get _fontIndex {
    if (_fontScale <= fontScaleSmall) return 0;
    if (_fontScale >= fontScaleLarge) return 2;
    return 1;
  }

  void _setFontScale(int index) async {
    final double value = _scaleSteps[index];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('font_scale', value);
    setState(() { _fontScale = value; });
    fontScaleNotifier.value = value;
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Settings")),
      body: ListView(
        children: [
          SwitchListTile(title: const Text("Save captures to Gallery"), subtitle: const Text("Automatically save photos taken with the app camera to your phone's gallery."), value: _saveToGallery, activeColor: Colors.tealAccent, onChanged: _toggleGallerySave),
          SwitchListTile(title: const Text("Save history of captured results"), subtitle: const Text("Keep a record of the medicines you have previously scanned in the History tab."), value: _saveHistory, activeColor: Colors.tealAccent, onChanged: _toggleHistorySave),
          SwitchListTile(title: const Text("Show camera center guide"), subtitle: const Text("Display a guide box in the center of the camera preview to help you position the drug. It does not change or crop the captured photo."), value: _centerGuide, activeColor: Colors.tealAccent, onChanged: _toggleCenterGuide),
          const Divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Font Size", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text("Adjust the text size across the app. Current: ${_scaleLabels[_fontIndex]}.", style: const TextStyle(color: Colors.white70, fontSize: 14)),
                Slider(
                  value: _fontIndex.toDouble(),
                  min: 0,
                  max: 2,
                  divisions: 2,
                  label: _scaleLabels[_fontIndex],
                  activeColor: Colors.tealAccent,
                  onChanged: (value) => _setFontScale(value.round()),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: List.generate(_scaleLabels.length, (i) => Text(
                    _scaleLabels[i],
                    style: TextStyle(
                      fontSize: 14,
                      color: i == _fontIndex ? Colors.tealAccent : Colors.white54,
                      fontWeight: i == _fontIndex ? FontWeight.bold : FontWeight.normal,
                    ),
                  )),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TermsScreen extends StatelessWidget { 
  const TermsScreen({super.key}); 
  @override Widget build(BuildContext context) { 
    return Scaffold(
      appBar: AppBar(title: const Text("Terms and Agreement")), 
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0), 
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, 
          children: [
            const Text("User Agreement & Disclaimer", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), 
            const SizedBox(height: 20), 
            Container(
              padding: const EdgeInsets.all(15), 
              decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.teal)), 
              child: const Text(userAgreementText, style: TextStyle(fontSize: 14, height: 1.5), textAlign: TextAlign.justify)
            )
          ]
        )
      )
    ); 
  } 
}

class AppDetailsScreen extends StatelessWidget { 
  const AppDetailsScreen({super.key}); 
  @override Widget build(BuildContext context) { 
    return Scaffold(
      appBar: AppBar(title: const Text("Application Details")), 
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0), 
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center, 
          children: [
            const Icon(Icons.medication_liquid, size: 80, color: Colors.tealAccent), const SizedBox(height: 20), 
            const Text("Medisina Scan", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), 
            const SizedBox(height: 30), 
            const Text("Medisina Scan is a machine learning-powered thesis prototype designed to classify 10 specific over-the-counter loose medicines commonly found in the Philippines.\n\nPowered by a customized Vision model, it aims to assist users in visually identifying pills that may have lost their primary packaging.", textAlign: TextAlign.justify, style: TextStyle(fontSize: 16, height: 1.5)), 
            const SizedBox(height: 30), 
            
            Container(
              padding: const EdgeInsets.all(15), 
              width: double.infinity, 
              decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.tealAccent.withValues(alpha: 0.5))), 
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start, 
                children: [
                  Text("Technical Specifications", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.tealAccent)), 
                  Divider(), 
                  SizedBox(height: 5), 
                  Text("• App Version: 1.0.1", style: TextStyle(fontSize: 14, height: 1.5)), 
                  Text("• Model Used: MobileViT-XS (Vision Transformer)", style: TextStyle(fontSize: 14, height: 1.5)), 
                  Text("• Release Date: April 2026", style: TextStyle(fontSize: 14, height: 1.5)), 
                  Text("• Platform Support: Android (iOS planned for future release)", style: TextStyle(fontSize: 14, height: 1.5)), 
                  Text("• Development Framework: Flutter 3.29", style: TextStyle(fontSize: 14, height: 1.5)), 
                ]
              )
            ), 
            const SizedBox(height: 40), 
            const Text("Developed for Academic Purposes Only", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.tealAccent))
          ]
        )
      )
    ); 
  } 
}