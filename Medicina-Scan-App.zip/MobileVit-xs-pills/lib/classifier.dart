import 'dart:convert';
import 'dart:io';
import 'dart:math'; // Added for Softmax math
import 'package:flutter/services.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;

class Classifier {
  Interpreter? _interpreter;
  List<String>? _labels;
  String _initStatus = "Initializing...";

  static const int inputSize = 256;
  static const int numClasses = 10;

  // Standard PyTorch ImageNet Normalization values
  static const double meanR = 0.485;
  static const double meanG = 0.456;
  static const double meanB = 0.406;
  static const double stdR = 0.229;
  static const double stdG = 0.224;
  static const double stdB = 0.225;

  Future<void> loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset('assets/medicine_classifier_float32.tflite');
      
      final labelData = await rootBundle.loadString('assets/labels.json');
      final decoded = json.decode(labelData);
      
      if (decoded is Map) {
        _labels = decoded.values.map((e) => e.toString()).toList();
      } else if (decoded is List) {
        _labels = decoded.map((e) => e.toString()).toList();
      } else {
        throw Exception("Unknown labels.json format");
      }
      
      _initStatus = "Success";
    } catch (e) {
      _initStatus = "Load Error: $e";
      print(_initStatus);
    }
  }

  Future<Map<String, dynamic>?> classifyImage(File imageFile) async {
    if (_interpreter == null) return {"label": "App crashed", "confidence": _initStatus};
    if (_labels == null) return {"label": "Labels crashed", "confidence": _initStatus};

    try {
      final imageBytes = await imageFile.readAsBytes();
      img.Image? originalImage = img.decodeImage(imageBytes);
      if (originalImage == null) return {"label": "Error", "confidence": "Image decode failed"};

      // Resize to the model input size (256 x 256, the training input).
      img.Image resizedImage = img.copyResize(originalImage, width: inputSize, height: inputSize);

      // Enhance contrast so light-gray shadows on pills stand out better for the model
      img.Image contrastEnhanced = img.contrast(resizedImage, contrast: 120);

      var input = List.generate(
        1,
        (i) => List.generate(
          inputSize,
          (y) => List.generate(
            inputSize,
            (x) {
              final pixel = contrastEnhanced.getPixel(x, y);
              
              // 1. Scale to [0, 1]
              double r = pixel.r / 255.0;
              double g = pixel.g / 255.0;
              double b = pixel.b / 255.0;

              // 2. Apply PyTorch Normalization (THIS FIXES THE INACCURACY)
              r = (r - meanR) / stdR;
              g = (g - meanG) / stdG;
              b = (b - meanB) / stdB;

              return [r, g, b];
            },
          ),
        ),
      );

      var output = List.generate(1, (i) => List.filled(numClasses, 0.0));

      // Run Inference
      _interpreter!.run(input, output);
      final results = output[0]; // These are RAW LOGITS

      // 3. Apply Softmax (THIS FIXES THE 400% BUG)
      double maxLogit = results.reduce(max); // For numerical stability
      double sumExp = 0.0;
      List<double> probabilities = [];

      for (int i = 0; i < results.length; i++) {
        double expValue = exp(results[i] - maxLogit);
        probabilities.add(expValue);
        sumExp += expValue;
      }

      double maxProb = 0.0;
      int maxIndex = 0;

      for (int i = 0; i < probabilities.length; i++) {
        probabilities[i] /= sumExp; // Final percentage (0.0 to 1.0)
        
        if (probabilities[i] > maxProb) {
          maxProb = probabilities[i];
          maxIndex = i;
        }
      }

      return {
        "label": _labels![maxIndex],
        "confidence": "${(maxProb * 100).toStringAsFixed(1)}%", // e.g., "99.8%"
      };
    } catch (e) {
      return {"label": "Inference Crash", "confidence": e.toString()};
    }
  }

  void close() {
    _interpreter?.close();
  }
}